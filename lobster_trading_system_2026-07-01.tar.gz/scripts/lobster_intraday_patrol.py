#!/usr/bin/env python3
"""龙虾盘中巡检 v1.0 - 统一买卖点监控(合并原买点/卖点/尾盘3个任务)

调度:
  10:00,10:30,13:00,13:30,14:00,14:30 → 常规巡检
  14:45 → 尾盘专项(加情绪定调+异动扫描)
  14:50 → 超短卖点预警(涨停次日未封板→卖出)

逻辑:一次采集 → 先卖后买 → 统一输出
"""

import json, subprocess, re, sys, datetime, os
from pathlib import Path
from collections import Counter

# ==================== 开盘时间验证 ====================
def is_trading_hours():
    now = datetime.datetime.now()
    hm = now.strftime("%H:%M")
    return ("09:15" <= hm < "09:30" or "09:30" <= hm < "11:30" or "13:00" <= hm < "15:00")

if not is_trading_hours():
    print(f"⏸️ 非交易时间 ({datetime.datetime.now().strftime('%H:%M')}),巡检跳过")
    sys.exit(0)

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
from simulated_trading import buy, sell, sell_partial, status as trade_status, emotion_force_sell

# ==================== 配置 ====================
CANDIDATES_PATH = "/tmp/lobster_watchlist_candidates.json"
POSITIONS_PATH = BASE.parent / "trading" / "模拟持仓.json"

# 止损线从lobster-config.json读取,支持动态微调
_CONFIG_PATH = Path(__file__).resolve().parent.parent / 'lobster-config.json'
def _load_stop_loss():
    try:
        with open(_CONFIG_PATH) as f:
            cfg = json.load(f)
        sl = cfg.get('stop_loss', {})
        return {
            '1.0一进二': sl.get('1.0', {}).get('hard_stop_pct', -7.0),
            '1.0分歧低吸': sl.get('1.0', {}).get('hard_stop_pct', -7.0),
            '2.0板块卡位': sl.get('2.0', {}).get('hard_stop_pct', -7.0),
            '3.0趋势低吸': -3.0,
        }
    except:
        return {'1.0一进二': -7.0, '1.0分歧低吸': -7.0, '2.0板块卡位': -7.0, '3.0趋势低吸': -3.0}
STOP_LOSS = _load_stop_loss()

# ==================== 信号强度分类 ====================
def classify_signal_strength(reason):
    """根据卖出原因分类信号强度,返回 (强度, 卖出比例)
    强度: 'weak' / 'medium' / 'strong'
    卖出比例: 0.33 / 0.5 / 1.0
    """
    # 🔴 强信号 → 全卖
    strong_keywords = ['硬止损', '强制止损', '逻辑证伪', '强制移出', '时间止损']
    if any(kw in reason for kw in strong_keywords):
        return 'strong', 1.0

    # 🔶 中信号 → 卖1/2
    medium_keywords = ['止盈', '分时止盈', '技术止损', '回落', '未封板']
    if any(kw in reason for kw in medium_keywords):
        return 'medium', 0.5

    # ⚠️ 弱信号 → 卖1/3
    return 'weak', 0.33

def _load_take_profit_config():
    """从lobster-config.json读取分时止盈配置"""
    try:
        with open(_CONFIG_PATH) as f:
            cfg = json.load(f)
        return cfg.get('intraday_take_profit', {})
    except:
        return {'min_profit_pct': 5.0, 'callback_threshold_pct': 5.0}
BASE_POSITION_PCT = {'1.0分歧低吸': 10, '1.0一进二': 10, '2.0板块卡位': 10, '3.0趋势低吸': 15}

def _get_dim_max_hold_days(dimension):
    """从lobster-config.json读取该维度的max_hold_days"""
    try:
        with open(CONFIG_PATH) as f:
            cfg = json.load(f)
        max_days_map = cfg.get('intraday_take_profit', {}).get('max_hold_days', {})
        for dim_key in ['1.0', '2.0', '3.0']:
            if dim_key in dimension:
                return max_days_map.get(dim_key, 5)
        return 5  # 兜底
    except:
        return 5

def _get_dim_min_hold_days(dimension):
    """从lobster-config.json读取该维度的min_hold_days，无配置则返回0"""
    try:
        with open(CONFIG_PATH) as f:
            cfg = json.load(f)
        dims = cfg.get('dimensions', {})
        for dim_key in ['1.0', '2.0', '3.0']:
            if dim_key in dimension:
                return dims.get(dim_key, {}).get('min_hold_days', 0)
        return 0
    except:
        return 0

CONFIG_PATH = BASE.parent / "lobster-config.json"

def load_emotion_matrix():
    """从config加载情绪矩阵"""
    try:
        with open(CONFIG_PATH) as f:
            cfg = json.load(f)
        return cfg.get('emotion', {})
    except:
        return {}

def get_emotion_tier(up_count, matrix):
    """根据涨跌家数返回 (tier_key, pos_limit, dominant_dim)"""
    if not matrix:
        return None, 10, '1.0'
    if up_count < 1600:
        tier = matrix.get('below_1600', {})
    elif up_count < 2000:
        tier = matrix.get('1600_2000', {})
    elif up_count < 2500:
        tier = matrix.get('2000_2500', {})
    elif up_count < 3500:
        tier = matrix.get('2500_3500', {})
    else:
        tier = matrix.get('above_3500', {})
    return tier.get('dim','1.0'), tier.get('pos_limit_pct', 50), tier.get('dim','1.0')

def emotion_triple_check(base_dim, base_pos_limit, today_up, yesterday_up, today_volume=None, yesterday_volume=None, intraday_high=None, intraday_low=None):
    """情绪三重校验(v2.5规则 + 盘中波动增强)
    base_dim/base_pos_limit: 基础判定结果
    today_up/yesterday_up: 今日/昨日涨跌家数
    today_volume/yesterday_volume: 今日/昨日成交额(可选,用于缩量修正)
    intraday_high/intraday_low: 盘中涨跌家数最高/最低值(新增,用于盘中剧烈波动检测)

    返回: (修正后dim, 修正后pos_limit, 修正说明列表)
    """
    corrections = []
    dim = base_dim
    pos_limit = base_pos_limit

    # 维度降级顺序:2.0+1.0+3.0 → 1.0+3.0 → 1.0 → 辅助模式
    dim_order = ['2.0+1.0+3.0', '1.0+3.0', '1.0']
    dim_pos_map = {'2.0+1.0+3.0': 7, '1.0+3.0': 9, '1.0': 5}

    # 🔴 新增: 盘中波动校验(日内振幅>800触发降级)
    if intraday_high and intraday_low:
        intraday_swing = intraday_high - intraday_low
        if intraday_swing > 800:
            # 盘中剧烈波动,强制降为保守仓位
            new_pos = max(pos_limit // 2, 20)  # 最低20%
            corrections.append(f"盘中剧烈波动(高{intraday_high}→低{intraday_low},振幅{intraday_swing}), 仓位{pos_limit}%→{new_pos}%")
            pos_limit = new_pos
            # 维度降一级
            try:
                idx = dim_order.index(dim) if dim in dim_order else len(dim_order)
                if idx < len(dim_order) - 1:
                    dim = dim_order[idx + 1]
            except:
                pass

    # 校验1:剧烈波动日(今日较前日变化>1600)
    if yesterday_up and yesterday_up > 0:
        delta = abs(today_up - yesterday_up)
        if delta > 1600:
            # 降一级:找当前维度在降级顺序中的前一个
            try:
                idx = dim_order.index(dim) if dim in dim_order else len(dim_order)
                if idx < len(dim_order) - 1:
                    new_dim = dim_order[idx + 1]
                    new_pos = dim_pos_map.get(new_dim, pos_limit)
                else:
                    new_dim = dim  # 已经最低
                    new_pos = min(pos_limit, 30)  # 极端保守,最低30%
                corrections.append(f"剧烈波动日(delta={delta}), {dim}→{new_dim}, 仓位{pos_limit}%→{new_pos}%")
                dim = new_dim
                pos_limit = new_pos
            except:
                pass

    # 校验2:缩量修正(今日成交额<前日,不得升级只能维持或降级)
    if today_volume and yesterday_volume and yesterday_volume > 0:
        if today_volume < yesterday_volume:
            # 如果基础判定已升级(vs昨日),则降回
            corrections.append(f"缩量修正(今{today_volume/1e8:.0f}亿<昨{yesterday_volume/1e8:.0f}亿), 禁止升级")
            # 缩量时仓位上限额外收紧10%
            pos_limit = max(pos_limit - 10, 10)

    # 校验3:极端值校验(涨跌家数>4000或<500触发预警)
    if today_up > 4000 or today_up < 500:
        corrections.append(f"⚠️ 极端值预警(涨跌{today_up}), 需人工确认数据有效性")
        # 极端值时保守处理:仓位减半
        pos_limit = max(pos_limit // 2, 10)

    return dim, pos_limit, corrections

def adjust_position_pct(base_pct, pos_limit_pct, used_pct):
    """根据情绪矩阵动态调整仓位比例

    pos_limit_pct: 总仓位上限(单位:%,如30表示30%)
    base_pct: 维度基础单仓比例(单位:%,如10表示10%)
    used_pct: 当前已占用仓位百分比(单位:%,如15表示15%)

    return: 本次可买单仓比例(单位:%)
    """
    remaining_pct = pos_limit_pct - used_pct
    if remaining_pct <= 0:
        return 0

    # 单仓上限 = min(维度基准, 剩余额度)
    return round(min(base_pct, remaining_pct), 1)

# ==================== 数据采集(一次完成) ====================
def fetch_emotion():
    """获取实时涨跌家数(多源保活)"""
    import sys, os

    # 添加scripts目录到path
    script_dir = os.path.dirname(os.path.abspath(__file__))
    if script_dir not in sys.path:
        sys.path.insert(0, script_dir)

    # === 主源:腾讯接口采样估算 ===
    try:
        from get_market_sentiment import get_sentiment_legacy_format
        sentiment = get_sentiment_legacy_format()
        if sentiment['up'] > 0 or sentiment['down'] > 0:
            return sentiment
    except Exception as e:
        print(f"腾讯接口采样失败: {e}")

    # === 降级源:新浪财经 ===
    try:
        ups = downs = zts = dts = 0
        import urllib.request as _ur
        import json as _json
        for pg in [1, 2, 3]:
            u = f"https://vip.stock.finance.sina.com.cn/quotes_service/api/json_v2.php/Market_Center.getHQNodeData?page={pg}&num=100&sort=code&asc=1&node=hs_a"
            req = _ur.Request(u, headers={"User-Agent": "Mozilla/5.0"})
            with _ur.urlopen(req, timeout=8) as resp:
                items = _json.loads(resp.read().decode('gbk'))
            for i in items:
                cp = float(i.get('changepercent', 0))
                if cp > 0: ups += 1
                elif cp < 0: downs += 1
                if cp >= 9.8: zts += 1
                elif cp <= -9.8: dts += 1
            if ups + downs > 100:
                return {'up': ups, 'down': downs, 'zt': zts, 'dt': dts, 'src': 'sina'}
    except:
        pass
    return None

def fetch_quotes(codes):
    """批量获取实时行情 {code: {price, pct, vol, high, low, name}}"""
    if not codes:
        return {}
    ql = [f"sh{c}" if c.startswith('6') else f"sz{c}" for c in codes]
    r = subprocess.run(["curl","-s","--max-time","10",f"https://qt.gtimg.cn/q={','.join(ql)}"],
                      capture_output=True, timeout=12)
    for enc in ["gb2312","gbk","utf-8"]:
        try: txt = r.stdout.decode(enc); break
        except: continue
    else: txt = r.stdout.decode("utf-8","replace")
    quotes = {}
    for line in txt.split(";"):
        m = re.search(r'v_(\w+)="([^"]*)"', line)
        if m:
            p = m.group(2).split("~")
            if len(p) > 37:
                code = p[2]
                quotes[code] = {
                    'price': float(p[3]) if p[3] else 0,
                    'pct': float(p[32]) if len(p) > 32 else 0,
                    'vol': float(p[36]) if len(p) > 36 else 0,
                    'high': float(p[33]) if len(p) > 33 else 0,
                    'low': float(p[34]) if len(p) > 34 else 0,
                    'last_close': float(p[4]) if p[4] else 0,
                    'name': p[1],
                }
    return quotes

def fetch_kline(code, days=10):
    """获取K线数据"""
    prefix = 'sh' if code.startswith('6') else 'sz'
    url = f"https://web.ifzq.gtimg.cn/appstock/app/fqkline/get?_var=kline_dayhfq&param={prefix}{code},day,,,{days},qfq"
    try:
        r = subprocess.run(['curl', '-s', '--max-time', '10', url], capture_output=True, timeout=12)
        m = re.search(r'kline_dayhfq=(.*)', r.stdout.decode('utf-8', 'replace'))
        if not m: return []
        data = json.loads(m.group(1))
        raw = data.get('data', {}).get(f'{prefix}{code}', {})
        klines = raw.get('qfqday', raw.get('day', []))
        return [{'close': float(k[2]), 'volume': int(float(k[5]))} for k in klines]
    except:
        return []

def calc_ma(klines, period):
    if len(klines) < period: return None
    return sum(k['close'] for k in klines[-period:]) / period

# ==================== 价格合理性校验 ====================
def validate_position_prices(positions, quotes):
    """校验持仓价格合理性，防止停牌/异常情况取到涨停价等失真价格。

    校验规则：
    1. 计算涨停价 = last_close * 1.1（四舍五入到2位小数）
    2. 如果 current_price == 涨停价，但 high != 涨停价（即未真正封板），用 high 替代
    3. 如果价格等于昨收且成交量极小（疑似停牌），用 high 替代
    4. 如果价格 > high（价格超出日内最高，异常），用 high 修正

    返回: 修正后的 quotes 字典 + 修正日志列表
    """
    corrections = []
    if not positions or not quotes:
        return quotes, corrections

    for pos in positions:
        code = pos['code']
        name = pos.get('name', code)
        q = quotes.get(code)
        if not q or q.get('price', 0) == 0:
            continue

        price = q['price']
        high = q.get('high', 0)
        last_close = q.get('last_close', 0)
        vol = q.get('vol', 0)

        if last_close <= 0:
            continue

        # 计算涨停价（A股主板 ±10%，科创板/创业板 ±20%）
        # 简化：先按 10% 计算，后续可按代码前缀细化
        if code.startswith('30') or code.startswith('688'):
            limit_up_pct = 1.20
        else:
            limit_up_pct = 1.10

        limit_up = round(last_close * limit_up_pct, 2)

        corrected = False
        new_price = price
        reason_parts = []

        # 规则1: 当前价等于涨停价但未真正封板（high != 涨停价）
        if abs(price - limit_up) < 0.01 and high > 0 and abs(high - limit_up) > 0.01:
            new_price = high
            reason_parts.append(f"现价={price}(涨停价{limit_up})→修正为当日最高{high}")
            corrected = True

        # 规则2: 疑似停牌（价格=昨收 且 量极小）
        if abs(price - last_close) < 0.01 and vol < 100:
            if high > 0 and high > price:
                new_price = max(high, last_close)
                reason_parts.append(f"疑似停牌(量{vol}手,价=昨收{last_close})→修正为{new_price}")
                corrected = True

        # 规则3: 价格超出日内最高（异常数据）
        if high > 0 and price > high * 1.001 and abs(price - limit_up) > 0.01:
            new_price = high
            reason_parts.append(f"现价{price}>最高{high}(异常)→修正为{high}")
            corrected = True

        if corrected:
            reason_str = " + ".join(reason_parts)
            corrections.append(f"[价格修正] {name}({code}): {reason_str}")
            quotes[code] = {**q, 'price': new_price, '_price_corrected': True,
                          '_original_price': price, '_correction_reason': reason_str}

    return quotes, corrections
# ==================== 卖点检测 ====================
def detect_sellpoints(positions, quotes):
    """检测所有持仓卖点,返回 [(code, name, reason, action)]"""
    triggers = []
    sellable = [p for p in positions if p.get('can_sell')]
    if not sellable:
        return triggers

    for pos in sellable:
        code = pos['code']
        name = pos['name']
        q = quotes.get(code)
        if not q or q['price'] == 0:
            continue
        buy_price = float(pos.get('buy_price', pos.get('avg_cost', pos.get('cost', 0) / pos.get('shares', 1))))
        pnl_pct = (q['price'] - buy_price) / buy_price * 100
        dim = pos.get('dimension', '')
        hold_days = (datetime.date.today() - datetime.datetime.strptime(pos['buy_date'], '%Y-%m-%d').date()).days

        # 🔒 min_hold_days保护：持仓天数不足时跳过卖出（但硬止损-7%除外）
        min_days = _get_dim_min_hold_days(dim)
        if min_days > 0 and hold_days < min_days:
            sl = STOP_LOSS.get(dim, -5.0)
            if pnl_pct > sl:  # 未触发硬止损，跳过
                continue

        reason = None

        # 1.0/2.0 硬止损
        sl = STOP_LOSS.get(dim, -5.0)
        if pnl_pct <= sl:
            reason = f"{dim}硬止损:回撤{pnl_pct:.2f}% ≤ {sl:.0f}%"

        # 1.0 时间止损
        if not reason and '1.0' in dim and hold_days >= 3 and pnl_pct < 9.8:
            reason = f"1.0时间止损:持仓{hold_days}天未涨停"

        # 3.0 窄止损（从config读取，默认-5%）
        if not reason and '3.0' in dim:
            narrow_stop = cfg.get('3.0_趋势低吸', {}).get('narrow_stop_pct', -5.0)
            if pnl_pct <= narrow_stop:
                reason = f"3.0趋势低吸硬止损:回撤{pnl_pct:.2f}% ≤ {narrow_stop}%"

        # 3.0 MA5<MA10 技术止损
        if not reason and '3.0' in dim:
            klines = fetch_kline(code, 12)
            ma5 = calc_ma(klines, 5)
            ma10 = calc_ma(klines, 10)
            if ma5 and ma10 and ma5 < ma10:
                reason = f"3.0技术止损:MA5({ma5:.2f})<MA10({ma10:.2f})"

        # 超短卖点(14:50后,涨停次日未封板)
        now_min = datetime.datetime.now().hour * 60 + datetime.datetime.now().minute
        if not reason and now_min >= 890 and '1.0' in dim:  # 14:50=890
            # 必须确认昨日确实涨停(涨幅≥9.5%),否则不触发
            # 检查持仓买入后昨日涨幅:用buy_price对比昨日收盘价
            # 简化:当前涨幅<7%且昨日涨停→未封板卖出;非涨停股不触发此规则
            buy_date_str = pos.get('buy_date', '')
            was_limit_up_yesterday = False
            if buy_date_str:
                try:
                    # 查询昨日K线确认是否涨停
                    import akshare as ak
                    hist = ak.stock_zh_a_hist(symbol=code, period='daily', start_date=buy_date_str.replace('-',''), end_date='', adjust='qfq')
                    if len(hist) >= 2:
                        yesterday_close = hist.iloc[-2]['收盘']  # 昨日收盘
                        day_before_close = hist.iloc[-3]['收盘'] if len(hist) >= 3 else hist.iloc[-2]['开盘']  # 前日收盘
                        yesterday_pct = (yesterday_close - day_before_close) / day_before_close * 100
                        was_limit_up_yesterday = yesterday_pct >= 9.5
                except:
                    pass  # 数据获取失败则保守不触发
            if was_limit_up_yesterday and q['pct'] < 7:
                reason = f"超短卖点:涨停次日未封板(昨涨≥9.5%,现{q['pct']:.1f}%)"

        # 分时止盈(盈利>min_profit_pct才启用,回调>callback_threshold_pct触发)
        # 🔴 Q7修复: profit_taken>=1时跳过，防止跨轮无限触发分时止盈
        if not reason and pnl_pct > 0 and pos.get('profit_taken', 0) < 1:
            tp_cfg = _load_take_profit_config()
            if pnl_pct >= tp_cfg.get('min_profit_pct', 5.0) and hold_days >= 1:
                # 盈利达标,检查日内高点回落比例
                day_high = q.get('high', q['price'])
                if day_high > 0 and day_high > buy_price:
                    peak_pct = (day_high - buy_price) / buy_price * 100  # 最高点盈利%
                    callback_pct = peak_pct - pnl_pct  # 从高点回落的百分点
                    if callback_pct >= tp_cfg.get('callback_threshold_pct', 5.0):
                        reason = f"分时止盈:最高盈利{peak_pct:.1f}%回落{callback_pct:.1f}%≥{tp_cfg['callback_threshold_pct']}%"

        # 通用时间止损（按维度从config读取max_hold_days）
        if not reason:
            dim_max_days = _get_dim_max_hold_days(dim)
            if hold_days >= dim_max_days:
                reason = f"时间止损:持仓{hold_days}天 ≥ {dim_max_days}天(dim:{dim})"

        if reason:
            # sell_type: 亏损→止损, 盈利→止盈, 规则名含止损→止损
            if '止损' in reason:
                sell_type_val = "止损"
            elif pnl_pct < 0:
                sell_type_val = "止损"
            else:
                sell_type_val = "止盈"

            # 根据信号强度决定卖出比例
            strength, pct_to_sell = classify_signal_strength(reason)
            if pct_to_sell >= 1.0:
                # 🔴 强信号 → 全卖
                sell(code, q['price'], reason, sell_type_val)
                triggers.append((code, name, reason, 'SELL_ALL'))
            else:
                # ⚠️/🔶 弱/中信号 → 部分卖
                pct_int = int(pct_to_sell * 100)  # 0.33→33, 0.5→50
                result = sell_partial(code, pct_int, q['price'], reason, sell_type_val)
                print(f"   {result}")
                triggers.append((code, name, reason, f'SELL_{int(pct_to_sell*100)}%'))

    return triggers

# ==================== 买点检测 ====================
def detect_buypoints(candidates, quotes, emotion, intraday_high=None, intraday_low=None, dynamic_pos_limit=None):
    """检测买点,返回 [(code, name, reason, action)]"""
    triggers = []
    used_pcts = []  # 累计仓位百分比追踪(替代原len计数)

    # 🔴 Q3修复: 读取当前已有持仓的总仓位占比，避免used_pcts从0开始导致仓位上限形同虚设
    current_total_pct = 0.0
    try:
        with open(POSITIONS_PATH) as f:
            _pos_data = json.load(f)
        total_assets = _pos_data.get('capital', {}).get('total_assets', 0)
        if total_assets > 0:
            current_total_pct = sum(p.get('cost', 0) for p in _pos_data.get('positions', [])) / total_assets * 100
    except:
        pass
    if not candidates:
        return triggers

    up_count = emotion.get('up', 0) if emotion else 0
    if up_count <= 0:
        return triggers  # 数据不可用,保守跳过

    # 情绪矩阵驱动
    emotion_matrix = load_emotion_matrix()
    dominant_dim, pos_limit, _ = get_emotion_tier(up_count, emotion_matrix)

    # 情绪三重校验（v2.5 + 盘中波动）
    state_path = BASE.parent / "trading" / "系统状态.json"
    yesterday_up = None
    try:
        with open(state_path) as sf:
            state = json.load(sf)
        yesterday_up = state.get('yesterday', {}).get('up_count')
    except:
        pass
    dominant_dim, pos_limit, corrections = emotion_triple_check(
        dominant_dim, pos_limit, up_count, yesterday_up, intraday_high=intraday_high, intraday_low=intraday_low)
    if corrections:
        print(f"🔧 情绪三重校验修正: {'; '.join(corrections)}")

    # 动态仓位调节覆盖：如果动态仓位上限更保守，使用动态值
    if dynamic_pos_limit is not None and dynamic_pos_limit < pos_limit:
        old_limit = pos_limit
        pos_limit = dynamic_pos_limit
        print(f"🔧 动态仓位覆盖: {old_limit}%→{pos_limit}% (盘中调节)")

    print(f"🎮 情绪矩阵: {up_count}涨 → 主导{dominant_dim}, 仓位上限{pos_limit}%")

    # 极冰点保护:<800涨时不做分歧低吸(接飞刀风险极高)
    extreme_freeze = up_count < 800

    for dim in ['1.0分歧低吸', '2.0板块卡位', '3.0趋势低吸']:
        for item in candidates.get(dim, []):
            code = str(item.get('代码', item.get('code', '')))
            name = item.get('名称', item.get('name', ''))
            if not code or code not in quotes:
                continue
            # 盘中实时解锁3.0:盘前打熔断标签,但盘中实时进入推理区/严格解锁则自动解除锁定
            is_30_melt = (item.get('locked') and '熔断' in item.get('锁定原因', ''))
            # 读配置
            cfg_30 = {}
            try:
                with open(CONFIG_PATH) as _f:
                    _cfg = json.load(_f)
                    cfg_30 = _cfg.get('3.0_emotion_rules', {})
            except: pass
            melt_below = cfg_30.get('melt_below', 1800)
            infer_zone = cfg_30.get('inference_zone', {})
            infer_low = infer_zone.get('low', 1800)
            infer_high = infer_zone.get('high', 2500)
            full_above = cfg_30.get('full_activate_above', 2500)
            # 判断解锁状态
            in_infer_zone = infer_low <= up_count <= infer_high
            in_full_unlock = up_count > full_above
            realtime_unlocked = is_30_melt and (in_infer_zone or in_full_unlock)
            # 推理区四维评分(仅推理区需要)
            inference_score = 0
            if is_30_melt and in_infer_zone:
                # 昨日情绪评分
                try:
                    _yesterday_up = json.load(open(BASE.parent / 'trading' / '系统状态.json')).get('yesterday', {}).get('up_count', 9999)
                except: _yesterday_up = 9999
                if _yesterday_up < 1600: inference_score += 2
                elif _yesterday_up < 2000: inference_score += 1
                # 修复速度评分(简化:当前up_count vs 昨日)
                if _yesterday_up > 0:
                    _delta = up_count - _yesterday_up
                    if _delta >= 300: inference_score += 2
                    elif _delta >= 200: inference_score += 1
                # 板块强度(涨停家数)
                if emotion and emotion.get('zt', 0) > 50: inference_score += 1
                # 量能确认:暂不评分(无盘中成交额对比数据源)
                # TODO: 接入Level-2逐笔成交额或分钟级K线后补充
            infer_passed = (not is_30_melt) or (realtime_unlocked and inference_score >= 3)
            if item.get('status') == '已买入' or (is_30_melt and not infer_passed):
                continue

            q = quotes[code]
            # 涨停错过→移出
            if q['pct'] >= 9.8:
                item['status'] = '涨停错过'
                continue

            reason = None

            if dim == '1.0分歧低吸':
                reason = _check_divergence_low(code, name, quotes, q)
            elif dim == '2.0板块卡位':
                reason = _check_sector_leader(code, name, item, q)
            elif dim == '3.0趋势低吸':
                reason = _check_trend_low(code, name, quotes, q, up_count, item, realtime_unlocked)

            if reason:
                # 🔴 P0 FIX: 过滤跌破MA5/MA10拒绝信号(函数返回非空字符串却被当成买入信号)
                if '跌破MA5' in str(reason) or '跌破MA10' in str(reason):
                    continue  # 破位移出,不加入新列表
                # 极冰点保护
                if extreme_freeze and dim == '1.0分歧低吸':
                    reason = f"[极冰点跳过] {reason}"
                    continue
                # 🔴 Q4修复: 极端高潮/冰点时只允许3.0维度进入买入检测
                # emotion_force_sell清仓1.0/2.0后，避免detect_buypoints因dominant_dim='辅助'免过滤立即买回
                if up_count > 3500 or up_count < 1600:
                    if dim != '3.0趋势低吸':
                        continue

                # 情绪维度过滤:非主导维度不盘中买入
                # 推理区解锁的3.0绕过维度过滤
                dim_prefix = dim.split('-')[0]
                if not (dim == '3.0趋势低吸' and realtime_unlocked):
                    if dominant_dim not in ('辅助', dim_prefix) and dim_prefix not in dominant_dim.split('+'):
                        continue
                # 动态仓位(累积百分比追踪, P0 FIX: 替代原len计数穿透bug)
                # 🔴 Q3修复: 累加已有持仓占比，避免仓位上限形同虚设
                base_pct = BASE_POSITION_PCT.get(dim, 10)
                used_pct = sum(used_pcts)
                if used_pct + current_total_pct + base_pct > pos_limit:
                    continue  # 总仓位不足以容纳本次买入
                adj_pct = adjust_position_pct(base_pct, pos_limit, used_pct)
                # 推理区解锁的3.0仓位减半
                if dim == '3.0趋势低吸' and realtime_unlocked and in_infer_zone:
                    adj_pct = adj_pct / 2
                if adj_pct <= 0:
                    continue
                sector = item.get('sector', item.get('板块', item.get('track', item.get('产业逻辑', ''))))
                buy(code, name, q['price'], reason, dim, up_count=up_count, position_pct=adj_pct, sector=sector)
                item['status'] = '已买入'
                used_pcts.append(adj_pct)  # 记录已用仓位百分比
                triggers.append((code, name, reason, 'BUY'))
            else:
                pass  # 保留监控

    return triggers

def _check_divergence_low(code, name, quotes, q):
    """1.0分歧低吸:回踩MA5/MA10 + 缩量"""
    klines = fetch_kline(code, 10)
    if not klines or len(klines) < 5:
        return None
    ma5 = calc_ma(klines, 5)
    ma10 = calc_ma(klines, 10)
    if not ma5 or not ma10:
        return None
    if q['price'] < ma10 * 0.98:
        return f"跌破MA10({ma10:.2f})"
    # 缩量检查
    vol_5avg = sum(k['volume'] for k in klines[-5:]) / 5
    now = datetime.datetime.now()
    elapsed_min = (now.hour - 9) * 60 + now.minute - 25
    if now.hour >= 13:
        elapsed_min = 125 + (now.hour - 13) * 60 + now.minute
    if elapsed_min > 0:
        est_full_vol = q['vol'] / (elapsed_min / 240)
    else:
        est_full_vol = q['vol']
    if est_full_vol > vol_5avg * 1.2:
        return None  # 量能未缩
    if q['pct'] > 3:
        return None  # 涨幅过大
    return f"分歧低吸:回踩MA5({ma5:.2f})/MA10({ma10:.2f})不破 + 缩量({q['vol']:.0f}手→预估{est_full_vol:.0f}手≤均量{vol_5avg:.0f}手)"

def _check_sector_leader(code, name, item, q):
    """2.0板块卡位:板块前排高开"""
    # 简化:竞价未通过的不追高,等下次竞价
    return None

def _check_trend_low(code, name, quotes, q, up_count, item, realtime_unlocked=False):
    """3.0趋势低吸:回踩均线"""
    locked = item.get('locked', False)
    melt_locked = locked and '熔断' in item.get('锁定原因', '')
    # 使用detect_buypoints传入的realtime_unlocked(已按配置计算)
    if melt_locked and not realtime_unlocked:
        return None  # 冰点熔断(盘中未修复)
    klines = fetch_kline(code, 12)
    ma5 = calc_ma(klines, 5)
    if not ma5:
        return None
    if q['price'] < ma5 * 0.98:
        return f"跌破MA5({ma5:.2f})"
    return f"趋势低吸:回踩MA5({ma5:.2f})不破 + 情绪{up_count}(盘中解锁)"

# ==================== 尾盘专项 ====================
def detect_t_opportunity(positions, quotes):
    """检测持仓做T机会:底仓日内低买高卖,降低成本
    条件:1) can_sell=True 2) 日内振幅>3% 3) 当前价接近日内低点 4) 可用资金充足
    """
    t_signals = []
    sellable = [p for p in positions if p.get('can_sell')]
    if not sellable:
        return t_signals

    # 读取做T配置(默认值)
    try:
        with open(CONFIG_PATH) as f:
            config = json.load(f)
        t_cfg = config.get('t_trade', {})
    except:
        t_cfg = {}

    min_swing_pct = t_cfg.get('min_swing_pct', 3.0)       # 最小振幅%
    max_near_low_pct = t_cfg.get('max_near_low_pct', 1.5)   # 距低点上限%
    max_t_ratio = t_cfg.get('max_t_ratio', 0.3)              # T仓占底仓上限
    t_take_profit_pct = t_cfg.get('t_take_profit_pct', 1.5) # T止盈%
    min_t_shares = t_cfg.get('min_t_shares', 100)            # 最小T股数(整手)
    min_profit_yuan = t_cfg.get('min_profit_yuan', 200)      # 最小利润元

    for pos in sellable:
        code = pos['code']
        name = pos['name']
        q = quotes.get(code, {})
        if not q:
            continue

        # 获取日内数据
        low = q.get('low', q.get('v_low', 0))
        high = q.get('high', q.get('v_high', 0))
        price = q.get('price', q.get('v_price', 0))
        prev_close = q.get('last_close', q.get('v_last_close', 0))

        try:
            low = float(low)
            high = float(high)
            price = float(price)
            prev_close = float(prev_close)
        except (TypeError, ValueError):
            continue

        if low <= 0 or high <= 0 or price <= 0 or prev_close <= 0:
            continue

        # 日内振幅
        swing_pct = (high - low) / prev_close * 100
        if swing_pct < min_swing_pct:
            continue

        # 当前价距日内低点
        near_low_pct = (price - low) / low * 100
        if near_low_pct > max_near_low_pct:
            continue

        # 计算T仓股数
        base_shares = pos['shares']
        t_shares = int(base_shares * max_t_ratio / 100) // 100 * 100  # 整手
        if t_shares < min_t_shares:
            t_shares = min_t_shares
        if t_shares > base_shares:
            t_shares = (base_shares // 100) * 100

        # 预期利润
        t_cost = t_shares * price
        expected_sell_price = price * (1 + t_take_profit_pct / 100)
        expected_profit = t_shares * (expected_sell_price - price) - t_shares * price * 0.003  # 扣双边手续费

        if expected_profit < min_profit_yuan:
            continue

        # 14:30后不做T(时间不够可能卖不出)
        now_min = datetime.datetime.now().hour * 60 + datetime.datetime.now().minute
        if now_min >= 14 * 60 + 30:
            continue

        reason = (f"做T机会: {name}({code}) 振幅{swing_pct:.1f}% 现价{price:.2f}"
                  f"(距低{near_low_pct:.1f}%) 建议买{t_shares}股@{price:.2f}"
                  f" → +{t_take_profit_pct}%即{expected_sell_price:.2f}卖")
        t_signals.append((code, name, reason, t_shares, price, expected_sell_price))

    return t_signals


def execute_t_trade(code, name, t_shares, buy_price, sell_price, reason):
    """执行做T:先买后卖,净持仓不变"""
    from simulated_trading import buy, sell_partial
    result_buy = buy(code, name, buy_price, reason, '1.0-做T', up_count=0, position_pct=0, allow_add=True, shares=t_shares)
    if '成功' in str(result_buy) or '买入' in str(result_buy):
        # 买入成功后立即挂卖单(仅卖T仓部分,按比例)
        # 计算T仓占新总持仓的百分比
        import json
        with open(POSITIONS_PATH) as f:
            pos_data = json.load(f)
        total_shares = 0
        for p in pos_data.get('positions', []):
            if p['code'] == code:
                total_shares = p['shares']
                break
        if total_shares > 0:
            pct_to_sell = t_shares / total_shares * 100
            result_sell = sell_partial(code, pct_to_sell, sell_price, f'做T止盈:+{((sell_price/buy_price)-1)*100:.1f}%', '做T止盈')
            return f"✅ 做T完成: 买{t_shares}股@{buy_price:.2f} → 卖{pct_to_sell:.1f}%持仓@{sell_price:.2f} | {result_buy} | {result_sell}"
        else:
            return f"❌ 做T失败: 无法获取{name}({code})持仓数据"
    else:
        return f"❌ 做T买入失败: {result_buy}"


def detect_add_position(positions, quotes, emotion_pos_limit=100):
    """检测今天新买入的持仓是否可加仓
    条件:1) can_sell=False(今天买) 2) 当前价较今日最高回撤>1.5%
          3) 总仓位未超限(min(情绪上限, 硬配置上限)) 4) 加仓后单只≤15%
          5) 加仓价不得高于成本价(禁止追高加仓)
    """
    add_signals = []
    today_positions = [p for p in positions if not p.get('can_sell')]
    if not today_positions:
        return add_signals

    # 读取配置
    try:
        with open(CONFIG_PATH) as f:
            config = json.load(f)
        add_cfg = config.get('add_position', {})
    except:
        add_cfg = {}

    min_pullback_pct = add_cfg.get('min_pullback_pct', 1.5)   # 最小回撤%
    max_add_ratio = add_cfg.get('max_add_ratio', 0.3)          # 加仓不超过原仓30%
    max_position_pct = add_cfg.get('max_position_pct', 15)     # 单只最大仓位%
    min_add_shares = add_cfg.get('min_add_shares', 100)        # 最小加仓股数
    hard_pct_limit = add_cfg.get('max_total_position_pct', 90)
    # 🔴 P0 FIX: 取情绪仓位上限和硬配置上限的较小值
    max_total_position_pct = min(emotion_pos_limit, hard_pct_limit)

    # 计算当前总仓位
    try:
        with open(POSITIONS_PATH) as f:
            pos_data = json.load(f)
        total_assets = pos_data.get('capital', {}).get('total_assets', 1000000)
        used_pct = sum(p.get('cost', 0) for p in pos_data.get('positions', [])) / total_assets * 100
    except:
        used_pct = 0

    if used_pct >= max_total_position_pct:
        return add_signals  # 总仓位已满(含情绪约束)

    for pos in today_positions:
        code = pos['code']
        name = pos['name']
        q = quotes.get(code, {})
        if not q:
            continue

        price = q.get('price', q.get('v_price', 0))
        high = q.get('high', q.get('v_high', 0))
        buy_price = pos.get('buy_price', pos.get('cost', 0)) / pos['shares'] if pos['shares'] > 0 else 0

        try:
            price = float(price)
            high = float(high)
            buy_price = float(buy_price)
        except (TypeError, ValueError, ZeroDivisionError):
            continue

        if price <= 0 or high <= 0 or buy_price <= 0:
            continue

        # 回撤幅度
        pullback_pct = (high - price) / high * 100
        if pullback_pct < min_pullback_pct:
            continue  # 回撤不够,不追

        # 🔴 P0 FIX: 加仓价不得高于成本均价(禁止追高加仓,只允许成本下方或平价加)
        if price > buy_price * 1.005:
            continue  # 加仓价比成本高→跳过(规则:加仓是摊低成本,不是追高)

        # 加仓股数:不超过原仓30%,凑100股整手
        add_shares = int(pos['shares'] * max_add_ratio / 100) // 100 * 100
        if add_shares < min_add_shares:
            add_shares = min_add_shares

        # 加仓后成本检查(不超过单只上限)
        add_cost = add_shares * price
        new_position_cost = pos.get('cost', 0) + add_cost
        new_position_pct = new_position_cost / total_assets * 100
        if new_position_pct > max_position_pct:
            # 降到上限
            max_add_cost = total_assets * max_position_pct / 100 - pos.get('cost', 0)
            add_shares = max(0, int(max_add_cost / price / 100) * 100)
            if add_shares < min_add_shares:
                continue

        # 总仓位检查
        add_pct = add_cost / total_assets * 100
        if used_pct + add_pct > max_total_position_pct:
            # 降到总仓位上限
            max_add_cost = total_assets * max_total_position_pct / 100 - sum(p.get('cost', 0) for p in pos_data.get('positions', []))
            add_shares = max(0, int(max_add_cost / price / 100) * 100)
            if add_shares < min_add_shares:
                continue

        reason = (f"加仓机会: {name}({code}) 最高{high:.2f}回撤{pullback_pct:.1f}% "
                  f"建议加{add_shares}股@{price:.2f} "
                  f"(原仓{pos['shares']}股,加后{pos['shares']+add_shares}股)")
        add_signals.append((code, name, reason, add_shares, price))

    return add_signals


def calc_current_position_pct(positions, total_assets):
    """计算当前持仓占总资产百分比"""
    if not positions or not total_assets:
        return 0.0
    total_cost = sum(p.get('cost', 0) for p in positions)
    return round(total_cost / total_assets * 100, 1) if total_assets else 0.0


def adjust_dynamic_position(emotion, pos_data, quotes):
    """盘中动态仓位调节：每轮巡检重新判定情绪区间，对比当前仓位动态调整
    
    逻辑：
    1. 读取当前情绪和目标仓位上限
    2. 计算当前实际仓位%
    3. 如果当前 > 上限 + 缓冲 → 触发减仓（优先减浮盈少的）
    4. 如果当前 < 上限 - 缓冲 → 允许加仓（正常走买点检测）
    """
    triggers = []
    if not emotion or emotion.get('up', 0) <= 0:
        return triggers, None, None
    
    up_count = emotion['up']
    em = load_emotion_matrix()
    dominant_dim, target_pos_limit, _ = get_emotion_tier(up_count, em)
    
    positions = pos_data.get('positions', [])
    capital = pos_data.get('capital', {})
    total_assets = capital.get('total_assets', 1000000)
    current_pct = calc_current_position_pct(positions, total_assets)
    
    # 缓冲带（防止情绪在区间边缘来回跳动触发减仓/加仓）
    HYSTERESIS_BUFFER = 5  # 百分点
    
    # 情绪区间描述
    tier_names = {0: '冰点', 1: '修复', 2: '强修复', 3: '高潮', 4: '极度高潮'}
    if up_count < 1600:
        tier_name = '冰点(<1600)'
    elif up_count < 2000:
        tier_name = '修复(1600-2000)'
    elif up_count < 2500:
        tier_name = '强修复(2000-2500)'
    elif up_count < 3500:
        tier_name = '高潮(2500-3500)'
    else:
        tier_name = '极度高潮(>3500)'
    
    print(f"📊 动态仓位: 情绪{up_count}涨→{tier_name} | 目标上限{target_pos_limit}% | 当前仓位{current_pct}%")
    
    # --- 减仓逻辑：当前 > 上限 + 缓冲 ---
    if current_pct > target_pos_limit + HYSTERESIS_BUFFER:
        excess_pct = current_pct - target_pos_limit
        # 按浮动盈亏排序（浮盈少的优先减）
        sorted_pos = sorted(positions, key=lambda p: p.get('total_pnl_pct', 0), reverse=False)
        reduce_target_pct = excess_pct
        
        for p in sorted_pos:
            if reduce_target_pct <= 0:
                break
            if not p.get('can_sell'):
                continue  # T+1未解锁
            
            code = p['code']
            name = p['name']
            pos_pct = p.get('cost', 0) / total_assets * 100
            
            # 卖出比例：当前标的占超额的比例（但至少卖30%以确保快速降仓）
            sell_ratio = min(reduce_target_pct / pos_pct, 0.7) if pos_pct > 0 else 0.3
            sell_ratio = max(sell_ratio, 0.3)  # 至少卖30%
            
            pnl_pct = p.get('total_pnl_pct', 0)
            reason = f"动态减仓:情绪回落至{tier_name},目标上限{target_pos_limit}%,当前{current_pct}%,减{sell_ratio*100:.0f}%"
            
            # 执行
            q = quotes.get(code, {})
            sell_price = q.get('price', 0)
            if sell_price <= 0:
                continue
                
            sell_type_val = "止损" if pnl_pct < 0 else "止盈"
            if sell_ratio >= 0.95:
                from simulated_trading import sell
                sell(code, sell_price, reason, sell_type_val)
                triggers.append((code, name, reason, f'SELL_ALL(dynamic)'))
                reduce_target_pct -= pos_pct
            else:
                pct_int = int(sell_ratio * 100)
                from simulated_trading import sell_partial
                sell_partial(code, pct_int, sell_price, reason, sell_type_val)
                triggers.append((code, name, reason, f'SELL_{pct_int}%(dynamic)'))
                reduce_target_pct -= pos_pct * sell_ratio
        
        print(f"  🚨 仓位超限{excess_pct:.1f}%, 触发减仓")
    
    # --- 加仓解锁：当前 < 上限 - 缓冲 ---
    elif current_pct < target_pos_limit - HYSTERESIS_BUFFER:
        avail_pct = target_pos_limit - current_pct
        print(f"  ✅ 仓位充裕({avail_pct:.1f}%), 允许加仓")
    
    else:
        print(f"  ➖ 仓位在缓冲区内(±{HYSTERESIS_BUFFER}%), 保持当前")
    
    return triggers, dominant_dim, target_pos_limit


def late_session_check(emotion, quotes, positions):
    """14:45+尾盘专项"""
    outputs = []
    if not emotion:
        return outputs

    up = emotion['up']
    if up < 1600: phase = "冰点"
    elif up < 2000: phase = "弱势"
    elif up < 2500: phase = "温和"
    elif up < 3500: phase = "活跃"
    else: phase = "极度高潮"

    outputs.append(f"📍 尾盘定调: {up}涨/{emotion['down']}跌 → {phase}")

    # 情绪减仓提示
    if up < 1600:
        outputs.append("🚨 冰点→建议清仓非1.0持仓")
    elif up > 3500:
        outputs.append("🔴 极度高潮→辅助模式,仓位上限20%")

    # 涨停池快查
    try:
        import akshare as ak
        today = datetime.date.today().strftime("%Y%m%d")
        df = ak.stock_zt_pool_em(date=today)
        if len(df) > 0:
            sectors = Counter(df.get('所属行业', df.get('板块', [])).tolist())
            top3 = sectors.most_common(3)
            outputs.append(f"🔥 今日涨停: {len(df)}只 | {' | '.join(f'{s}:{c}只' for s, c in top3)}")
    except:
        pass

    return outputs

# ==================== 盘中候选池补生 ====================
def intraday_screen_candidates(emotion, quotes, positions, min_amount=5):
    """盘中实时筛选候选股

    触发条件：候选池缺失 / 来自前一天 / 早上 cron 失败
    逻辑：从今日强势板块中挖掘回踩买点（不追高，只做回踩）
    返回格式同 premarket：{'1.0一进二': [], '1.0分歧低吸': [], '2.0板块卡位': [], '3.0趋势低吸': []}
    """
    import akshare as ak
    today = datetime.date.today().strftime('%Y%m%d')
    candidates = {
        '1.0一进二': [],
        '1.0分歧低吸': [],
        '2.0板块卡位': [],
        '3.0趋势低吸': []
    }

    up_count = emotion.get('up', 0) if emotion else 0
    dominant_dim = '1.0'
    if up_count >= 2500:
        dominant_dim = '2.0'

    # 获取持仓已有板块（避免重复买同类）
    held_sectors = set()
    for p in positions:
        sector = p.get('sector', '')
        if sector:
            held_sectors.add(sector)

    # ── 数据源1：今日涨停池 → 提取热门板块 ──
    hot_sectors = []
    zt_stocks = []
    try:
        df_zt = ak.stock_zt_pool_em(date=today)
        if len(df_zt) > 0:
            cols = df_zt.columns.tolist()
            sector_col = '所属行业' if '所属行业' in cols else ('板块' if '板块' in cols else None)
            if sector_col:
                sector_cnt = Counter(df_zt[sector_col].dropna().tolist())
                hot_sectors = [s for s, _ in sector_cnt.most_common(5)]
            name_col = '名称' if '名称' in cols else '股票名称'
            code_col = '代码'
            zt_stocks = {
                str(row[code_col]): row[name_col]
                for _, row in df_zt.iterrows()
            }
    except Exception as e:
        print(f'  ⚠️ 涨停池获取失败: {e}')

    # ── 数据源2：板块资金流（补充热点） ──
    try:
        df_flow = ak.stock_sector_fund_flow_rank(indicator='今日', sector_type='行业资金流向')
        if df_flow is not None and len(df_flow) > 0:
            cols = df_flow.columns.tolist()
            for _, row in df_flow.head(5).iterrows():
                sector_name = str(row.get(cols[0], ''))
                if sector_name and sector_name not in hot_sectors:
                    hot_sectors.append(sector_name)
    except:
        pass

    if not hot_sectors:
        print('  ⚠️ 无热门板块数据，跳过盘中筛选')
        return candidates

    print(f'  📡 盘中筛选：热门板块 {hot_sectors}')

    # ── 数据源3：板块成分股 → 筛选回踩标的 ──
    seen_codes = set(p['code'] for p in positions)  # 排除已有持仓
    sector_stocks = []

    for sector_name in hot_sectors[:3]:  # 只看前3热门板块
        try:
            df_sec = ak.stock_board_industry_cons_em(symbol=sector_name)
            if df_sec is None or len(df_sec) == 0:
                continue
            cols = df_sec.columns.tolist()
            # 筛选成交额够大的标的
            amt_col = [c for c in cols if '成交额' in c or '成交' in c or '金额' in c]
            pct_col = [c for c in cols if '涨跌幅' in c or '涨幅' in c or '涨跌' in c]
            name_col_ind = [c for c in cols if c in ['名称', '股票名称', '股票']]
            code_col_ind = [c for c in cols if c == '代码']

            if not (amt_col and pct_col and name_col_ind and code_col_ind):
                continue

            amt_col, pct_col, name_col_ind, code_col_ind = amt_col[0], pct_col[0], name_col_ind[0], code_col_ind[0]

            for _, row in df_sec.iterrows():
                try:
                    code = str(int(row[code_col_ind])).zfill(6)
                    if code in seen_codes:
                        continue
                    amount_str = str(row[amt_col])
                    amount = float(amount_str.replace('亿', '').replace('万', '').replace('元', '').replace(',', '').strip())
                    if '万' in amount_str:
                        amount /= 10000
                    if amount < min_amount:  # 成交额不足5亿跳过
                        continue
                    pct = float(str(row[pct_col]).replace('%', '').strip())
                    name = str(row[name_col_ind])
                    sector_stocks.append({
                        'code': code, 'name': name,
                        'pct': pct, 'amount': amount,
                        'sector': sector_name
                    })
                    seen_codes.add(code)
                except:
                    pass
        except Exception as e:
            print(f'  ⚠️ 板块{sector_name}成分股获取失败: {e}')

    if not sector_stocks:
        print('  ⚠️ 板块成分股数据为空')
        return candidates

    # ── 筛选买点：回踩型（不是追高） ──
    # 规则：涨幅 0%~7%（不是涨停也不是大跌），成交额充足
    # 理想买点：回踩MA5/MA10 或 从日内高位回落3-8%
    now_hm = datetime.datetime.now().strftime('%H:%M')
    is_afternoon = datetime.datetime.now().hour >= 13

    for stock in sector_stocks:
        code = stock['code']
        name = stock['name']
        pct = stock['pct']
        sector = stock['sector']

        # 过滤：涨停错过 / 已大跌 / ST
        if pct >= 9.5 or pct <= -5 or 'ST' in name:
            continue

        q = quotes.get(code)
        if not q or q.get('price', 0) == 0:
            continue

        price = q['price']
        high = q.get('high', price)

        # 计算日内高点回落幅度
        pullback_pct = 0.0
        if high > price > 0:
            pullback_pct = (high - price) / high * 100

        klines = fetch_kline(code, 10)
        ma5 = calc_ma(klines, 5) if klines else None
        ma10 = calc_ma(klines, 10) if klines else None

        reason = None
        dim = None

        # 买点判断
        if dominant_dim in ('2.0', '2.0+1.0+3.0') or dominant_dim == '1.0+3.0':
            # 2.0板块卡位：回踩MA5/MA10，板块强势
            if ma10 and abs(price - ma10) / ma10 < 0.03:  # 偏离MA10<3%
                reason = f'2.0盘中卡位:{sector}回踩MA10({ma10:.2f})现{price},高位回落{pullback_pct:.1f}%'
                dim = '2.0板块卡位'
            elif ma5 and abs(price - ma5) / ma5 < 0.02 and pct > 0:  # 贴着MA5且上涨
                reason = f'2.0盘中卡位:{sector}回踩MA5({ma5:.2f})现{price},板块支撑'
                dim = '2.0板块卡位'

        elif dominant_dim == '1.0':
            # 1.0分歧低吸：超跌反弹（上午>2%大跌 或 午盘>3%大跌）
            threshold = 2.0 if not is_afternoon else 3.0
            if pct < -threshold and pct > -9:
                reason = f'1.0盘中分歧低吸:{name}下跌{pct:.1f}%回踩MA10({ma10:.2f if ma10 else "?"})'
                dim = '1.0分歧低吸'

        if reason and dim:
            candidates[dim].append({
                '名称': name, '代码': code,
                'sector': sector, 'pct': pct,
                'amount': stock['amount'],
                'pullback_pct': pullback_pct,
                'ma5': round(ma5, 2) if ma5 else None,
                'ma10': round(ma10, 2) if ma10 else None,
                'status': '盘中新增',
                'source': '盘中筛选'
            })

    # 限制每个维度候选数量
    for dim in candidates:
        candidates[dim] = candidates[dim][:5]

    new_count = sum(len(v) for v in candidates.values())
    if new_count > 0:
        print(f'  ✅ 盘中筛选新增 {new_count} 只候选')
        for dim, items in candidates.items():
            if items:
                items_str = ', '.join([f'{s["名称"]}({s["pct"]:+.1f}%)' for s in items])
                print(f'    {dim}: {items_str}')

    return candidates


def check_and_regenerate_candidates(emotion, quotes, positions):
    """检查候选池是否需要盘中补生"""
    today = datetime.date.today().strftime('%Y-%m-%d')
    candidates = {}
    regenerated = False

    try:
        with open(CANDIDATES_PATH) as f:
            cand_data = json.load(f)
        file_date = cand_data.get('date', '')
        if file_date == today:
            candidates = cand_data.get('candidates', {})
            print(f'  ✅ 候选池有效（{file_date}，{sum(len(v) for v in candidates.values())}只）')
        else:
            print(f'  ⚠️ 候选池过期（{file_date} ≠ {today}），盘中补生...')
            regenerated = True
    except (FileNotFoundError, json.JSONDecodeError):
        print(f'  ⚠️ 候选池缺失，盘中补生...')
        regenerated = True

    if regenerated:
        candidates = intraday_screen_candidates(emotion, quotes, positions)
        # 写回文件（供后续轮次使用）
        try:
            with open(CANDIDATES_PATH, 'w') as f:
                json.dump({'date': today, 'candidates': candidates, 'source': 'intraday_regen'}, f)
        except:
            pass

    return candidates, regenerated


# ==================== 主函数 ====================
def run():
    now = datetime.datetime.now()
    now_min = now.hour * 60 + now.minute
    now_hm = now.strftime("%H:%M")
    is_late = now_min >= 14*60+45  # 14:45+

    print(f"{'='*50}")
    print(f"🔍 龙虾盘中巡检 {now_hm}{'(尾盘专项)' if is_late else ''}")
    print(f"{'='*50}")

    # 1. 采集情绪(含盘中波动追踪)
    emotion = fetch_emotion()
    intraday_high = intraday_low = None
    if emotion:
        up = emotion['up']
        # 🔴 盘中波动追踪: 读取/更新日内振幅文件
        swing_file = "/tmp/lobster_intraday_swing.json"
        try:
            with open(swing_file) as sf:
                swing_data = json.load(sf)
            intraday_high = swing_data.get('high')
            intraday_low = swing_data.get('low')
        except:
            swing_data = {}
        # 更新盘中最高/最低
        if intraday_high is None or up > intraday_high:
            intraday_high = up
        if intraday_low is None or up < intraday_low:
            intraday_low = up
        swing_data['high'] = intraday_high
        swing_data['low'] = intraday_low
        swing_data['last_update'] = now_hm
        try:
            with open(swing_file, 'w') as sf:
                json.dump(swing_data, sf)
        except:
            pass
        
        phase = "冰点" if up < 1600 else "弱势" if up < 2000 else "温和" if up < 2500 else "活跃" if up < 3500 else "极度高潮"
        swing_info = f"(日内{intraday_high}→{intraday_low})" if intraday_high and intraday_low and intraday_high != intraday_low else ""
        print(f"📡 情绪: {up}涨/{emotion['down']}跌 涨停{emotion['zt']} 跌停{emotion['dt']} → {phase} {swing_info}")
    else:
        print("⚠️ 情绪数据获取失败")
        emotion = {'up': -1, 'down': 0, 'zt': 0, 'dt': 0}

    # 2. 加载持仓 + 候选池,合并所有代码一次获取行情
    pos_data = {}
    try:
        with open(POSITIONS_PATH) as f:
            pos_data = json.load(f)
    except:
        pass

    positions = pos_data.get('positions', [])

    # 先收集持仓代码获取初始行情（候选池补生需要）
    position_codes = [p['code'] for p in positions if p.get('code')]
    quotes = fetch_quotes(position_codes) if position_codes else {}

    # ── 候选池检查 + 盘中补生 ──
    candidates, was_regenerated = check_and_regenerate_candidates(emotion, quotes, positions)

    # 盘中补生后：用实时行情更新候选池价格
    if was_regenerated and candidates:
        for dim in candidates:
            for item in candidates[dim]:
                code = str(item.get('代码', item.get('code', '')))
                if code in quotes:
                    item['实时价格'] = quotes[code].get('price')
                    item['实时涨幅'] = quotes[code].get('pct')
    # ── 合并候选池（盘中新增 + 盘前候选都保留）──
    # 注：盘中新增已在 intraday_screen 中写入 candidates{}，
    # 盘前已有候选保留在 cand_data（若读过则与 candidates 合并）
    try:
        with open(CANDIDATES_PATH) as f:
            premarket_data = json.load(f)
        premarket_cands = premarket_data.get('candidates', {})
        for dim, items in premarket_cands.items():
            if dim in candidates:
                # 合并：盘中新增 + 盘前保留（去重）
                existing_codes = {str(i.get('代码', i.get('code', ''))) for i in candidates[dim]}
                for item in items:
                    code = str(item.get('代码', item.get('code', '')))
                    if code and code not in existing_codes:
                        candidates[dim].append(item)
            else:
                candidates[dim] = items
    except:
        pass

    # 合并所有需要行情的代码
    all_codes = set()
    for p in positions:
        all_codes.add(p['code'])
    for dim in candidates.values():
        for item in dim:
            code = str(item.get('代码', item.get('code', '')))
            if code:
                all_codes.add(code)

    quotes = fetch_quotes(list(all_codes))
    print(f"📊 行情获取: {len(quotes)}只")

    # 2.3 价格合理性校验（防御停牌/涨跌停价格失真）
    quotes, price_corrections = validate_position_prices(positions, quotes)
    if price_corrections:
        print(f"⚠️ 价格修正: {len(price_corrections)}只持仓")
        for c in price_corrections:
            print(f"  {c}")

    # 2.4 情绪极端强制卖出（比动态仓位调节更优先的应激反应）
    if emotion and emotion.get('up', 0) > 0:
        up_count = emotion['up']
        price_map = {code: q['price'] for code, q in quotes.items() if q.get('price', 0) > 0}
        force_results = emotion_force_sell(pos_data, up_count, price_map)
        if force_results:
            print(f"🔴 情绪强制卖出: {len(force_results)}笔")
            for r in force_results:
                print(f"  {r}")
            # 重新加载持仓数据（emotion_force_sell内部已修改并保存）
            try:
                with open(POSITIONS_PATH) as f:
                    pos_data = json.load(f)
                positions = pos_data.get('positions', [])
            except:
                pass

    # 2.5 盘中动态仓位调节（根据实时情绪调整总仓位）
    dyna_triggers, active_dim, active_pos_limit = adjust_dynamic_position(emotion, pos_data, quotes)

    # 🔴 Q2修复: adjust_dynamic_position卖出后持仓文件已更新，重新加载避免detect_sellpoints使用过期positions
    try:
        with open(POSITIONS_PATH) as f:
            pos_data = json.load(f)
        positions = pos_data.get('positions', [])
    except:
        pass

    sell_triggers = detect_sellpoints(positions, quotes)

    # 合并动态减仓到卖点
    if dyna_triggers:
        sell_triggers.extend(dyna_triggers)
    buy_triggers = detect_buypoints(candidates, quotes, emotion, intraday_high, intraday_low, dynamic_pos_limit=active_pos_limit)

    # 3.5. 做T检测
    t_signals = detect_t_opportunity(positions, quotes)
    if t_signals:
        print(f"\n🔄 做T机会 {len(t_signals)}只:")
        for code, name, reason, t_shares, buy_price, sell_price in t_signals:
            print(f"  {reason}")
            result = execute_t_trade(code, name, t_shares, buy_price, sell_price, reason)
            print(f"  {result}")

    # 3.6. 加仓检测(今天新买入的标的,受情绪仓位上限约束)
    emotion_pos_limit = 100  # 默认不限制
    if emotion and emotion.get('up', 0) > 0:
        up_count = emotion['up']
        em = load_emotion_matrix()
        _, emotion_pos_limit, _ = get_emotion_tier(up_count, em)
    add_signals = detect_add_position(positions, quotes, emotion_pos_limit)
    if add_signals:
        print(f"\n📈 加仓机会 {len(add_signals)}只:")
        for code, name, reason, add_shares, price in add_signals:
            print(f"  {reason}")
            from simulated_trading import buy
            result = buy(code, name, price, reason, '1.0-加仓', up_count=0, position_pct=0, allow_add=True, shares=add_shares)
            print(f"  {result}")

    # 4. 输出结果
    if sell_triggers:
        print(f"\n🔴 卖点触发 {len(sell_triggers)}只:")
        for code, name, reason, _ in sell_triggers:
            print(f"  {name}({code}): {reason}")

    if buy_triggers:
        print(f"\n🔥 买点触发 {len(buy_triggers)}只:")
        for code, name, reason, _ in buy_triggers:
            print(f"  {name}({code}): {reason}")

    if not sell_triggers and not buy_triggers and not t_signals and not add_signals:
        monitor_count = sum(len(v) for v in candidates.values())
        pos_count = len(positions)
        print(f"\n✅ 无触发 | 监控{monitor_count}只 | 持仓{pos_count}只")

    # 5. 尾盘专项
    if is_late:
        late_out = late_session_check(emotion, quotes, positions)
        if late_out:
            print(f"\n{'─'*40}")
            for line in late_out:
                print(f"  {line}")

    # 6. 持仓状态
    if positions:
        print(f"\n{trade_status()}")

    # 7. 保存买点通知
    if buy_triggers:
        notify_path = f"/tmp/lobster_buy_notification_{datetime.date.today().strftime('%Y%m%d')}.txt"
        with open(notify_path, 'w') as f:
            f.write('\n'.join([f"🔥 {name}({code}): {reason}" for code, name, reason, _ in buy_triggers]))
        print(f"\n✅ 通知已保存: {notify_path}")

    print(f"\n⏱️ 巡检完成 {datetime.datetime.now().strftime('%H:%M:%S')}")

if __name__ == '__main__':
    run()
